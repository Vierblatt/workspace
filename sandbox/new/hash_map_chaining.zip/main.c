#include <stdio.h>
#include "hash_map_chaining.h"

int main() {
    HashTable ht;
    hash_table_init(&ht);
    hash_table_insert(&ht, 1, 100);
    hash_table_insert(&ht, 2, 200);
    hash_table_insert(&ht, 102, 300); // 冲突测试
    int val;
    hash_table_print(&ht);
    if (hash_table_find(&ht, 1, &val))
        printf("Key 1 found, value = %d\n", val);
    else
        printf("Key 1 not found\n");
    if (hash_table_find(&ht, 2, &val))
        printf("Key 2 found, value = %d\n", val);
    else
        printf("Key 2 not found\n");
    if (hash_table_find(&ht, 102, &val))
        printf("Key 102 found, value = %d\n", val);
    else
        printf("Key 102 not found\n");
    hash_table_remove(&ht, 2);
    hash_table_print(&ht);
    if (hash_table_find(&ht, 2, &val))
        printf("Key 2 found, value = %d\n", val);
    else
        printf("Key 2 not found after removal\n");
    // 自动扩容测试
    for (int i = 3; i < 20; ++i) {
        hash_table_insert(&ht, i, i * 10);
    }
    hash_table_print(&ht);
    hash_table_destroy(&ht);
    return 0;
}
